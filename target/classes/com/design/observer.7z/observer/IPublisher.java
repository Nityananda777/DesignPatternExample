package com.design.observer;

public interface IPublisher {
	void publish(String meesageKey,Message message);

}
