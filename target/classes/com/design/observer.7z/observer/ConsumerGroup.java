package com.design.observer;

public interface ConsumerGroup {
public void consume(Message message);
}
